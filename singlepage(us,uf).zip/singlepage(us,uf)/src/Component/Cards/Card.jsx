import React from 'react'


// import img7 from '../../img7.jpg'

const Card = (props) => {
  return (
    <>
   
<div className="card-group mx-auto" style={{width:'38rem',height:'25rem'}}>
  <div className="card">
    <img src={props.img} style={{width:'25', height:'25'}} className="card-img-top" alt="hi"/>
    <div className="card-body">
      <h5 className="name">{props.name}</h5>
      <p className="disc">{props.disc}</p>
      <p className="card-text"><small className="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  </div>
   </>
  )
}

export default Card
