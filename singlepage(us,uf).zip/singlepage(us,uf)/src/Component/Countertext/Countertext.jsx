import React, { useState, useEffect } from 'react';
import { Card, CardBody, CardTitle, CardSubtitle, Label, Input, Button } from 'reactstrap';
import './Countertext.css';

const Countertext = () => {
  const [text, setText] = useState('');

  const handleTextChange = (event) => {
    setText(event.target.value);
  };

  const uppercase = () => {
    setText(text.toUpperCase());
  };

  const lowercase = () => {
    setText(text.toLowerCase());
  };

  useEffect(() => {
    console.log('Component mounted!');
    return () => {
      console.log('Component unmounted!');
    };
  }, []);

  useEffect(() => {
    console.log('Text updated:', text);
  }, [text]);

  return (
    <Card>
      <CardBody>
        <CardTitle tag="h1" className='display-3'>Text Converter</CardTitle>
        <CardSubtitle tag="p" className='lead'>Convert text to uppercase or lowercase</CardSubtitle>
        <Label for="text-input">Enter some text:</Label>
        <Input id="text-input" type="text" value={text} onChange={handleTextChange} />
        <div>
          <h2>Uppercase:</h2>
          <Button className='uppercase' onClick={uppercase}>uppercase</Button>
        </div>
        <div>
          <h2>Lowercase:</h2>
          <Button className='lowercase' onClick={lowercase}>lowercase</Button>
        </div>
      </CardBody>
    </Card>
  );
};

export default Countertext;
