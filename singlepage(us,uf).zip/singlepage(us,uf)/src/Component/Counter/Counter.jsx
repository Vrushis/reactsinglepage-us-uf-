import React, { useEffect, useState } from 'react';
import "./Counter.css";

function Counter() {
  const [count, setCount] = useState(0);
  
  useEffect(() => {
    console.log('The count has changed!');
  }, [count]);

  const handleIncrement = () => {
    setCount(count + 1);
  };

  const handleDecrement = () => {
    setCount(count - 1);
  };

  return (
    <div class="card text-dark bg-info mb-3" >
    <div className='counter-container'>
        
    <h3> Example of Counter using usestate:-</h3>
      <h1 className='counter-text'>{count}</h1>
      <div className='button-container'>
        <button className='increment-button' onClick={handleIncrement}>+</button>
        <button className='decrement-button' onClick={handleDecrement}>-</button>
      </div>
    </div>
    </div>
  );
}

export default Counter;
