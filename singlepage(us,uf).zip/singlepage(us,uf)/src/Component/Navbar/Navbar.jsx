import React, { useState } from 'react'
import { FaFacebookSquare,FaInstagramSquare,FaYoutubeSquare } from "react-icons/fa";
import "./navbar.css";
import {GiHamburgerMenu } from 'react-icons/gi';
const Navbar = () => {
  const [showMediaIcons, setShowMediaIcons] = useState(false);
  return (
    <>
   <nav className='main-nav'>
    {/* 1 st logo */}
    <div className='logo'>
    <h2 className='text'>  <span>V</span>rushi
      <span>s</span>hah</h2>
    </div>
      {/* 2 nd part */}
    <div  className={showMediaIcons ? "menu-link mobile-menu-link" : "menu-link" }>
      <ul>
        <li>
          <a href="!#">Home</a>
        </li>
        <li>
          <a href="!#">About</a>
        </li>
        <li>
          <a href="!#">Services</a>
        </li>
        <li>
          <a href="!#">Contact</a>
        </li>
      </ul>

    </div>
    {/* 3 rd part */}

    <div className='social-media'>
      <ul className='social-media-desktop'>
        <li>
          <a href="https://www.youtube.com/watch?v=8AJ3Kcz5FsM&ab_channel=ThapaTechnical" target="_thapa" >
            <FaFacebookSquare className='facebook'/>
          </a>
        </li>
        <li>
          <a href="https://www.youtube.com/watch?v=8AJ3Kcz5FsM&ab_channel=ThapaTechnical" target="_thapa" >
            <FaInstagramSquare className='instagram'/>
          </a>
        </li>
        <li>
          <a href="https://www.youtube.com/watch?v=8AJ3Kcz5FsM&ab_channel=ThapaTechnical" target="_thapa" >
            <FaYoutubeSquare className='youtube'/>
          </a>
        </li>
      
      
      </ul>

      {/* hamburget */}

    <div className='hamburger-menu'>
    <a href='!#' onClick={()=>setShowMediaIcons(!showMediaIcons)}><GiHamburgerMenu/></a>

    </div>

    </div>
    </nav> 
    {/* hero section */}
      <section className='hero-section'>
        <p>Welcome to</p>
        <h1>Vrushi's Cartton univrse</h1>

      </section>
    
    </>
  )
}

export default Navbar
