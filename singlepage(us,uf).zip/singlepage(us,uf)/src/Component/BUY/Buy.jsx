import React from 'react'
import "./Buy.css";

const buy = () => {
  return (
    <> 
<div className="nombo_tm_intro_bottom">
    <p className="wow fadeInUp" data-wow-duration="0.8s" style={{visibility: 'visible'}}>
        Premium Quality Theme</p><h3 className="wow fadeInUp" data-wow-duration="0.8s" data-wow-delay="0.2s">
            Want To Buy This Theme?</h3> <a className="wow zoomIn" data-wow-duration="0.8s"
             href="!#" 
              style={{visibility: 'visible'}}>Buy Now</a></div>
    </>
  )
}

export default buy
