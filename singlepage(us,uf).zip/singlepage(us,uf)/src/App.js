import React from 'react'
import Card from './Component/Cards/Card'

import Buy from './Component/BUY/Buy'
import Navbar from "./Component/Navbar/Navbar"
import Slider from './Component/Slider/Slider'
import img1 from '../src/img1.jpg'
import img3 from '../src/img3.jpg'
import img4 from '../src/img4.jpg'
import Counter from './Component/Counter/Counter'

import Countertext from './Component/Countertext/Countertext'

const App = () => {
  return (
    <>
    <Navbar/>
    <Slider/>
    <br/>
    <div className='container mx-auto'>
      <div className='row'>
      <Card name="doremon" disc="i am doremon hear" img={img1}/>
      <Card name="shinchan" disc="i am shinchan hear" img={img3}/>
      <Card name="pickachu" disc="i am pikachuhear" img={img4}/>
    
      </div>
    </div>
    {/* <div>
      <Buy/>
    </div>
    <br></br> */}
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
   <div>
        <Counter/>
        
   </div>
   <Countertext/>
    <div>
      <Buy/>
    </div>
    </>
    
  )
}

export default App
